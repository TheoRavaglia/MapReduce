package advanced.customwritable;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

class GlobalReducer extends Reducer<Text, IntWritable, Text, Text> {
    private final Map<String, Integer> resultados = new HashMap<>();

    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) {
        String chave = key.toString();
        int soma = 0;
        for (IntWritable val : values) soma += val.get();
        resultados.put(chave, soma);
    }

    @Override
    protected void cleanup(Context context) throws IOException, InterruptedException {
        // Cabeçalho
        context.write(new Text("=== RESULTADOS ==="), null);

        // Questão 1
        context.write(new Text("\n1. Transações Brasil:"), null);
        context.write(new Text("Total"), new Text(resultados.getOrDefault("Q1_BRAZIL", 0).toString()));

        // Questão 2
        context.write(new Text("\n2. Transações por Ano:"), null);
        resultados.entrySet().stream()
                .filter(e -> e.getKey().startsWith("Q2_ANO_"))
                .forEach(e -> {
                    String ano = e.getKey().replace("Q2_ANO_", "");
                    try {
                        context.write(new Text(ano), new Text(e.getValue().toString()));
                    } catch (Exception ex) { ex.printStackTrace(); }
                });

        // Questão 3
        context.write(new Text("\n3. Transações por Categoria:"), null);
        resultados.entrySet().stream()
                .filter(e -> e.getKey().startsWith("Q3_CAT_"))
                .forEach(e -> {
                    String categoria = e.getKey().replace("Q3_CAT_", "");
                    try {
                        context.write(new Text(categoria), new Text(e.getValue().toString()));
                    } catch (Exception ex) { ex.printStackTrace(); }
                });
    }
}