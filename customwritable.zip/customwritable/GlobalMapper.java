package advanced.customwritable;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class GlobalMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
    private final static IntWritable ONE = new IntWritable(1);

    @Override
    protected void map(LongWritable key, Text value, Context context)
            throws IOException, InterruptedException {

        // Pula cabeçalho e linhas inválidas
        if (CSVUtils.isHeader(value.toString())) return;
        String[] cols = value.toString().split(";");
        if (!CSVUtils.isValidTransaction(cols)) return;

        // Questão 1: Transações Brasil
        if (cols[0].equalsIgnoreCase("Brazil")) {
            context.write(new Text("Q1_BRAZIL"), ONE);
        }

        // Questão 2: Transações por Ano
        context.write(new Text("Q2_ANO_" + cols[1]), ONE);

        // Questão 3: Transações por Categoria
        context.write(new Text("Q3_CAT_" + cols[9]), ONE);
    }
}