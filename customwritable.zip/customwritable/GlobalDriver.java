package advanced.customwritable;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.BasicConfigurator;

public class GlobalDriver {
    public static void main(String[] args) throws Exception {
        // Validação dos argumentos
        if (args.length != 2) {
            System.err.println("Erro: Use <caminho_entrada> <caminho_saida>");
            System.exit(1);
        }

        BasicConfigurator.configure();
        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "file:///");
        conf.set("mapreduce.framework.name", "local");
        conf.setInt("mapreduce.job.reduces", 1);

        Job job = Job.getInstance(conf, "ProcessamentoCompleto");
        job.setJarByClass(GlobalDriver.class);
        job.setMapperClass(GlobalMapper.class);
        job.setReducerClass(GlobalReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}