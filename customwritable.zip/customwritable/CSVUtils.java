package advanced.customwritable;

public class CSVUtils {
    public static boolean isHeader(String line) {
        // Verifica se é o cabeçalho (ajuste conforme seu CSV real)
        return line.startsWith("Country;Year;Commodity code;Commodity;Flow;Price;Weight;Unit;Amount;Category");
    }

    public static boolean isValidTransaction(String[] cols) {
        // Validações básicas (país, ano numérico, categoria)
        return cols.length == 10 &&
                !cols[0].isEmpty() &&
                cols[1].matches("\\d+") &&
                !cols[9].isEmpty();
    }
}