package q7;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class q7Mapper extends Mapper<Object, Text, Text, DoubleWritable> {
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();

        if (line.startsWith("Country")) return;

        String[] fields = line.split(";");
        if (fields.length < 10) return;

        String country = fields[0].trim();
        String year = fields[1].trim();
        String flow = fields[4].trim();
        String priceStr = fields[5].trim();

        if (!country.equalsIgnoreCase("Brazil") || !flow.equalsIgnoreCase("Export")) return;

        try {
            double price = Double.parseDouble(priceStr);
            context.write(new Text(year), new DoubleWritable(price));
        } catch (NumberFormatException ignored) {}
    }
}

