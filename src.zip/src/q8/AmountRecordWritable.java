package q8;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class AmountRecordWritable implements Writable {
    private DoubleWritable amount;
    private Text fullRecord;

    public AmountRecordWritable() {
        this.amount = new DoubleWritable();
        this.fullRecord = new Text();
    }

    public AmountRecordWritable(double amount, String record) {
        this.amount = new DoubleWritable(amount);
        this.fullRecord = new Text(record);
    }

    public double getAmount() {
        return amount.get();
    }

    public String getFullRecord() {
        return fullRecord.toString();
    }

    @Override
    public void write(DataOutput out) throws IOException {
        amount.write(out);
        fullRecord.write(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        amount.readFields(in);
        fullRecord.readFields(in);
    }
}
