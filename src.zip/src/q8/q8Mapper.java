package q8;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class q8Mapper extends Mapper<Object, Text, Text, AmountRecordWritable> {
    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();

        // Ignora cabeçalho
        if (line.startsWith("Country") || line.trim().isEmpty()) return;

        String[] fields = line.split(";");
        if (fields.length < 9) return;

        String country = fields[0].trim();
        String year = fields[1].trim();
        String amountStr = fields[8].trim(); // coluna 'amount'

        if (country.isEmpty() || year.isEmpty() || amountStr.isEmpty()) return;

        try {
            double amount = Double.parseDouble(amountStr.replace(",", ".")); // trata vírgula
            String keyOut = country + ";" + year;
            context.write(new Text(keyOut), new AmountRecordWritable(amount, line));
        } catch (NumberFormatException e) {
            // ignora valor inválido
        }
    }
}
