package CSVParser;

public class CSVParser {
    public static String[] parse(String line) {
        return line.split(";", -1);
    }

    public static boolean isHeader(String[] cols) {
        return cols.length > 0 && cols[0].equals("Country");
    }

    public static boolean isValid(String[] cols, int requiredLength) {
        return cols.length == requiredLength && !cols[0].isEmpty();
    }
}
