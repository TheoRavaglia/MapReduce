package q5;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import CSVParser.CSVParser;
import java.io.IOException;

public class q5Mapper extends Mapper<Object, Text, Text, DoubleWritable> {
    private Text yearKey = new Text();
    private DoubleWritable transactionValue = new DoubleWritable();

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        String[] fields = CSVParser.parse(line);

        if (CSVParser.isHeader(fields)) {
            return;
        }

        if (CSVParser.isValid(fields, 10)) {
            String country = fields[0];
            String year = fields[1];
            String priceStr = fields[5];

            if (country.equals("Brazil") && !priceStr.isEmpty()) {
                try {
                    double price = Double.parseDouble(priceStr);
                    yearKey.set(year);
                    transactionValue.set(price);
                    context.write(yearKey, transactionValue);
                } catch (NumberFormatException e) {
                    System.err.println("Valor invalido: " + priceStr + " na linha: " + line);
                }
            }
        }
    }
}
