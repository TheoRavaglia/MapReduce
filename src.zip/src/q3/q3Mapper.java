package q3;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import CSVParser.CSVParser;

import java.io.IOException;

public class q3Mapper extends Mapper<Object, Text, Text, IntWritable> {
    private final static IntWritable one = new IntWritable(1);
    private Text categoryKey = new Text();

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] fields = CSVParser.parse(value.toString());

        if (CSVParser.isHeader(fields) || !CSVParser.isValid(fields, 10)) return;

        String category = fields[9].trim();
        if (!category.isEmpty()) {
            categoryKey.set(category);
            context.write(categoryKey, one);
        }
    }
}
