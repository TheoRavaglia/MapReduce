package q4;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import CSVParser.CSVParser;

import java.io.IOException;

public class q4Mapper extends Mapper<Object, Text, Text, IntWritable> {
    private Text flowKey = new Text();
    private static final IntWritable one = new IntWritable(1);

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        String[] fields = CSVParser.parse(line);

        if (CSVParser.isHeader(fields)) {
            return;
        }

        if (CSVParser.isValid(fields, 10)) {
            String flow = fields[4];
            if (!flow.isEmpty()) {
                flowKey.set(flow);
                context.write(flowKey, one);
            }
        }
    }
}