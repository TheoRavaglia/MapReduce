package q1;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import CSVParser.CSVParser;

import java.io.IOException;

public class q1Mapper extends Mapper<Object, Text, Text, IntWritable> {
    private final static IntWritable one = new IntWritable(1);
    private final static Text brasilKey = new Text("Brasil");

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String[] fields = CSVParser.parse(value.toString());

        if (CSVParser.isHeader(fields) || !CSVParser.isValid(fields, 10)) return;

        String country = fields[0].trim();
        if (country.equalsIgnoreCase("Brazil")) {
            context.write(brasilKey, one);
        }
    }
}
