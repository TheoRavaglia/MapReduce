package q6;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class PriceRecordWritable implements Writable {
    private DoubleWritable price = new DoubleWritable();
    private Text record = new Text();

    public PriceRecordWritable() {}

    public PriceRecordWritable(double price, String record) {
        this.price.set(price);
        this.record.set(record);
    }

    public double getPrice() {
        return price.get();
    }

    public String getRecord() {
        return record.toString();
    }

    @Override
    public void write(DataOutput out) throws IOException {
        price.write(out);
        record.write(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        price.readFields(in);
        record.readFields(in);
    }
}
