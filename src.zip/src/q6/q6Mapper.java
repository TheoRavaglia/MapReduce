package q6;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;

public class q6Mapper extends Mapper<Object, Text, Text, PriceRecordWritable> {
    private static final Text outputKey = new Text("stats");

    @Override
    protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();

        // Remove cabeçalho
        if (line.startsWith("Country")) return;

        String[] fields = line.split(";");
        if (fields.length < 10) return;

        String country = fields[0].trim();
        String year = fields[1].trim();
        String priceStr = fields[5].trim();

        if (!country.equalsIgnoreCase("Brazil") || !year.equals("2016")) return;

        try {
            double price = Double.parseDouble(priceStr);
            context.write(outputKey, new PriceRecordWritable(price, line));
        } catch (NumberFormatException ignored) {}
    }
}
