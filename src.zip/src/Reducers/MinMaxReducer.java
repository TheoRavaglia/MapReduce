package Reducers;

import q8.AmountRecordWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;

public class MinMaxReducer extends Reducer<Text, AmountRecordWritable, Text, Text> {

    @Override
    protected void reduce(Text key, Iterable<AmountRecordWritable> values, Context context)
            throws IOException, InterruptedException {

        double min = Double.MAX_VALUE;
        double max = -Double.MAX_VALUE;
        String recMin = null, recMax = null;

        for (AmountRecordWritable val : values) {
            double amount = val.getAmount();
            String record = val.getFullRecord();

            if (amount < min) {
                min = amount;
                recMin = record;
            }
            if (amount > max) {
                max = amount;
                recMax = record;
            }
        }

        if (recMin != null && recMax != null) {
            context.write(new Text(key.toString() + " - Menor (" + min + ")"), new Text(recMin));
            context.write(new Text(key.toString() + " - Maior (" + max + ")"), new Text(recMax));
        }
    }
}
